package Sonnenschein.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;


import Sonnenschein.model.SensorApiResponse;
import Sonnenschein.model.SensorData;
import Sonnenschein.repository.SensorRepository;



@Service
public class SensorService {

	@Autowired
	private SensorRepository sensorRepository;

	@Autowired
	private RestTemplate restTemplate;
	
//	private final String API_URL_shelly = "http://192.168.188.95/status";
	private final String API_URL_shelly = "http://89.0.71.139/status";
	
	public SensorData getShellyData() {
	    System.out.println("getShellyData method called");
	    SensorData sensorData = new SensorData();
	    try {
	        SensorApiResponse response = restTemplate.getForObject(API_URL_shelly, SensorApiResponse.class);
	        System.out.println("API response: " + response);

	        if (response != null) {
	            // Set default timestamp if it's missing
	            String timestamp = response.getTime() != null ? response.getTime() : "N/A";
	            sensorData.setTimestamp(timestamp);
	            sensorData.setRoomTemperature(response.getTmp().getValue());
	            sensorData.setHumidity(response.getHum().getValue());

	            System.out.println(timestamp);
	            System.out.println(response.getTmp().getValue());
	            System.out.println(response.getHum().getValue());

	            
	            sensorRepository.save(sensorData); // Save in H2 Database
	        }
	    } catch (ResourceAccessException e) {
	        System.err.println("Error accessing the sensor API: " + e.getMessage());
	        // Handle the error, e.g., set default values or log the error
	        sensorData.setTimestamp("N/A");
	        sensorData.setRoomTemperature(0.0);
	        sensorData.setHumidity(0.0);
	    }
	    return sensorData;
	}
}





