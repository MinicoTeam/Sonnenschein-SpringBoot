package Sonnenschein.service;

import Sonnenschein.model.GeocodingApiResponse;
import Sonnenschein.model.IpApiResponse;
import Sonnenschein.model.WetterApiResponse;
import Sonnenschein.model.WetterData;
import Sonnenschein.repository.WetterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import java.util.function.Function;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;


@Service
public class WetterService {

	@Autowired
	private WetterRepository wetterRepository;

	@Autowired
	private RestTemplate restTemplate;

	// URL for current weather
	private final String API_URL = "https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current=temperature_2m,wind_speed_10m,wind_direction_10m,precipitation,weather_code,cloud_cover&forecast_days=1";
	
	// URL for hourly forecast
	private final String API_URL_hourly = "https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&hourly=temperature_2m,precipitation_probability,cloud_cover,wind_speed_10m,wind_direction_10m,weather_code&forecast_days=1";
	
	// URL for daily forecast
	private final String API_URL_daily = "https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max,wind_direction_10m_dominant&forecast_days=3";

	// URL for search for location via IP
	private final String API_URL_ip = "http://ip-api.com/json";
	
	// URL for Geocoding (search for location)
	private final String GEOCODING_API_URL = "https://nominatim.openstreetmap.org/search?q={location}&format=json";

	
	// method for searching default location based on IP
	
	private String getCoordinatesIP() {
		
		IpApiResponse ipResponse = restTemplate.getForObject(API_URL_ip, IpApiResponse.class);
		
		String location = ipResponse.getCity();
//		double lat = Double.parseDouble(ipResponse.getLat());
//		double lon = Double.parseDouble(ipResponse.getLon());

		return location;
	}
	// method for searching the GPS coordinates of given location
	
	private double[] getCoordinates(String location) {
		String geocodingUrl = GEOCODING_API_URL.replace("{location}", location);
		GeocodingApiResponse[] geocodingResponse = restTemplate.getForObject(geocodingUrl, GeocodingApiResponse[].class);

		if (geocodingResponse == null || geocodingResponse.length == 0) {
			throw new RuntimeException("Geocoding API returned no results");
		}

		
		double lat = Double.parseDouble(geocodingResponse[0].getLat());
		double lon = Double.parseDouble(geocodingResponse[0].getLon());

		return new double[]{lat, lon};
	}

	// method for calculating averages for 4 day parts (morning, day, evening, night)
	
	public List<Double> calculateAverage(List<WetterData> forecastHourly, Function<WetterData, Double> valueExtractor) {
		List<Double> averages = new ArrayList<>();
		int segmentSize = forecastHourly.size() / 4;

		DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.getDefault());
		symbols.setDecimalSeparator('.');
		DecimalFormat df = new DecimalFormat("#.0", symbols);


		for (int i = 0; i < 4; i++) {
			double sum = 0;
			for (int j = 0; j < segmentSize; j++) {
				sum += valueExtractor.apply(forecastHourly.get(i * segmentSize + j));
				}
			
			double average = sum / segmentSize;
			
			// round at 1 decimal digit and use . instead of ,
			averages.add(Double.valueOf(df.format(average))); 
			}

		return averages;
	}





	public WetterData fetchCurrentWeather(String location) {
		
		if (location == null || location.isEmpty()) {
	        location = getCoordinatesIP(); // get the default location per IP
	    }
		
		System.out.println(location);
		
		double[] coordinates = getCoordinates(location);
		double lat = coordinates[0];
		double lon = coordinates[1];

		String url = API_URL.replace("{lat}", String.valueOf(lat)).replace("{lon}", String.valueOf(lon));
		WetterApiResponse response = restTemplate.getForObject(url, WetterApiResponse.class);

		WetterData wetterData = new WetterData();
		if (response != null && response.getCurrent() != null) {
			wetterData.setTemperature(response.getCurrent().getTemperature_2m());
			//wetterData.setHumidity(response.getCurrent().getRelativeHumidity_2m());
			wetterData.setWindSpeed(response.getCurrent().getWindSpeed_10m());
			wetterData.setWindDirection(response.getCurrent().getWindDirection_10m());
			wetterData.setPrecipitation(response.getCurrent().getPrecipitation());
			wetterData.setCloudCover(response.getCurrent().getCloudCover());
			wetterData.setWeatherCode(response.getCurrent().getWeatherCode());
			wetterData.setTimestamp(response.getCurrent().getTime());
			wetterData.setLocation(location); 

			//            Long maxId = wetterRepository.findMaxId();
			//            wetterData.setId(maxId != null ? maxId + 1 : 1);

			wetterRepository.save(wetterData); // Save in H2 Database
		}
		return wetterData;
	}

	public List<WetterData> fetchHourlyForecast(String location) {
		double[] coordinates = getCoordinates(location);
		double lat = coordinates[0];
		double lon = coordinates[1];

		String url = API_URL_hourly.replace("{lat}", String.valueOf(lat)).replace("{lon}", String.valueOf(lon));
		WetterApiResponse response = restTemplate.getForObject(url, WetterApiResponse.class);

		List<WetterData> forecast = new ArrayList<>();
		if (response != null && response.getHourly() != null) {
			for (int i = 0; i < ((response.getHourly()).getTime().length); i++) {
				WetterData wetterData = new WetterData();
				wetterData.setTimestamp_hourly(response.getHourly().getTime()[i]);
				wetterData.setTemperature_2m(response.getHourly().getTemperature_2m()[i]);
				wetterData.setPrecipitation_probability(response.getHourly().getPrecipitation_probability()[i]);
				wetterData.setCloudCover_hourly(response.getHourly().getCloud_cover()[i]);
				wetterData.setWindSpeed_10m(response.getHourly().getWind_speed_10m()[i]);
				wetterData.setWindDirection_hourly(response.getHourly().getWind_direction_10m()[i]);
				wetterData.setWeatherCode_hourly(response.getHourly().getWeather_code()[i]);

				forecast.add(wetterData);

				//                Long maxId = wetterRepository.findMaxId();
				//                wetterData.setId(maxId != null ? maxId + 1 : 1);

				wetterRepository.save(wetterData); // Save in H2 Database
			}
		}
		return forecast;
	}

	public List<WetterData> fetchDailyForecast(String location) {
		double[] coordinates = getCoordinates(location);
		double lat = coordinates[0];
		double lon = coordinates[1];

		String url = API_URL_daily.replace("{lat}", String.valueOf(lat)).replace("{lon}", String.valueOf(lon));
		WetterApiResponse response = restTemplate.getForObject(url, WetterApiResponse.class);



		List<WetterData> forecast3 = new ArrayList<>();
		if (response != null && response.getDaily() != null) {
			for (int i = 0; i < ((response.getDaily()).getTime().length); i++) {
				WetterData wetterData = new WetterData();
				wetterData.setDate((response.getDaily()).getTime()[i]);
				wetterData.setTemperatureMax(response.getDaily().getTemperature_2m_max()[i]);
				wetterData.setTemperatureMin(response.getDaily().getTemperature_2m_min()[i]);
				wetterData.setPrecipitation_probability_max(response.getDaily().getPrecipitation_probability_max()[i]);
				wetterData.setWindSpeed(response.getDaily().getWind_speed_10m_max()[i]);
				wetterData.setWindDirection(response.getDaily().getWind_direction_10m_dominant()[i]);
				wetterData.setWeatherCode_daily(response.getDaily().getWeather_code()[i]);
				forecast3.add(wetterData);

				//                Long maxId = wetterRepository.findMaxId();
				//                wetterData.setId(maxId != null ? maxId + 1 : 1);

				wetterRepository.save(wetterData); // Save in H2 Database
			}
		}
		return forecast3;
	}

	public WetterData fetchCurrentWeather() {
		// TODO Auto-generated method stub
		return null;
	}
}