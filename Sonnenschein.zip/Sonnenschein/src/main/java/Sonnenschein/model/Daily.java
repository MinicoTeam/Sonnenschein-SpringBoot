package Sonnenschein.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Daily {
	@JsonProperty("time")
	private String[] time;
	@JsonProperty("temperature_2m_max")
	private double[] temperature_2m_max;
	@JsonProperty("temperature_2m_min")
	private double[] temperature_2m_min;
	@JsonProperty("precipitation_probability_max")
	private double[] precipitation_probability_max;
	@JsonProperty("weather_code")
	private int[] weather_code;
	@JsonProperty("wind_speed_10m_max")
	private double[] wind_speed_10m_max;
	@JsonProperty("wind_direction_10m_dominant")
	private double[] wind_direction_10m_dominant;
	
	
	public String[] getTime() {
		return time;
	}
	public void setTime(String[] time) {
		this.time = time;
	}
	public double[] getTemperature_2m_max() {
		return temperature_2m_max;
	}
	public void setTemperature_2m_max(double[] temperature_2m_max) {
		this.temperature_2m_max = temperature_2m_max;
	}
	public double[] getTemperature_2m_min() {
		return temperature_2m_min;
	}
	public void setTemperature_2m_min(double[] temperature_2m_min) {
		this.temperature_2m_min = temperature_2m_min;
	}
	public double[] getPrecipitation_probability_max() {
		return precipitation_probability_max;
	}
	public void setPrecipitation_probability_max(double[] precipitation_probability_max) {
		this.precipitation_probability_max = precipitation_probability_max;
	}
	public int[] getWeather_code() {
		return weather_code;
	}
	public void setWeather_code(int[] weather_code) {
		this.weather_code = weather_code;
	}
	public double[] getWind_speed_10m_max() {
		return wind_speed_10m_max;
	}
	public void setWind_speed_10m_max(double[] wind_speed_10m_max) {
		this.wind_speed_10m_max = wind_speed_10m_max;
	}
	public double[] getWind_direction_10m_dominant() {
		return wind_direction_10m_dominant;
	}
	public void setWind_direction_10m_dominant(double[] wind_direction_10m_dominant) {
		this.wind_direction_10m_dominant = wind_direction_10m_dominant;
	}
	
	
	
}

