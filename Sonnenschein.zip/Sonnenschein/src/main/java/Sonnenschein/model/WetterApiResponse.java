package Sonnenschein.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WetterApiResponse {
	
	@JsonProperty("current")
	private Current current;

	@JsonProperty("daily")
	private Daily daily;

	@JsonProperty("hourly")
	private Hourly hourly;

	
	// Getters and Setters
	public Current getCurrent() {
		return current;
	}

	public void setCurrent(Current current) {
		this.current = current;
	}

	public Daily getDaily() {
		return daily;
	}

	public void setDaily(Daily daily) {
		this.daily = daily;
	}


	public Hourly getHourly() {
		return hourly;
	}

	public void setHourly(Hourly hourly) {
		this.hourly = hourly;
	}
}



	

	

	