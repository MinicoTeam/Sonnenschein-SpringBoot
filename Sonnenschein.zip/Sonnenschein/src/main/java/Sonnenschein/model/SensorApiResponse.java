package Sonnenschein.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SensorApiResponse {

    @JsonProperty("time")
    private String time;

    @JsonProperty("tmp")
    private Tmp tmp;

    @JsonProperty("hum")
    private Hum hum;
    
//    @JsonProperty("is_valid")
//    private boolean isValid;
//
//    // Add other fields if needed
//    // Example:
//    @JsonProperty("wifi_sta")
//    private WifiSta wifiSta;
//
//    @JsonProperty("cloud")
//    private Cloud cloud;
//
//    @JsonProperty("mqtt")
//    private Mqtt mqtt;
//
//    @JsonProperty("unixtime")
//    private long unixtime;
//
//    @JsonProperty("serial")
//    private int serial;
//
//    @JsonProperty("has_update")
//    private boolean hasUpdate;
//
//    @JsonProperty("mac")
//    private String mac;
//
//    @JsonProperty("cfg_changed_cnt")
//    private int cfgChangedCnt;
//
//    @JsonProperty("actions_stats")
//    private ActionsStats actionsStats;

   

//    @JsonProperty("bat")
//    private Battery bat;
//
//    @JsonProperty("act_reasons")
//    private List<String> actReasons;
//
//    @JsonProperty("connect_retries")
//    private int connectRetries;
//
//    @JsonProperty("update")
//    private Update update;
//
//    @JsonProperty("ram_total")
//    private int ramTotal;
//
//    @JsonProperty("ram_free")
//    private int ramFree;

//    @JsonProperty("fs_size")
//    private int fsSize;
//
//    @JsonProperty("fs_free")
//    private int fsFree;
//
//    @JsonProperty("uptime")
//    private int uptime;

    // Getters and setters for all fields

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Tmp getTmp() {
        return tmp;
    }

    public void setTmp(Tmp tmp) {
        this.tmp = tmp;
    }

    public Hum getHum() {
        return hum;
    }

    public void setHum(Hum hum) {
        this.hum = hum;
    }
}