package Sonnenschein.model;
import com.fasterxml.jackson.annotation.JsonProperty;

public class IpApiResponse {

	@JsonProperty("city")
	private String city;
	@JsonProperty("lat")
	private String lat;
	@JsonProperty("lon")
	private String lon;
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLat() {
		return lat;
	}
	public void setLat(String lat) {
		this.lat = lat;
	}
	public String getLon() {
		return lon;
	}
	public void setLon(String lon) {
		this.lon = lon;
	}
	
	
	

}
