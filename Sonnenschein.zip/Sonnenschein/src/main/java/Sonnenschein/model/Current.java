package Sonnenschein.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Current {
	@JsonProperty("temperature_2m")
	private double temperature_2m;
	@JsonProperty("relative_humidity_2m")
	private double relativeHumidity_2m;
	@JsonProperty("wind_speed_10m")
	private double windSpeed_10m;
	@JsonProperty("wind_direction_10m")
	private double windDirection_10m;
	@JsonProperty("precipitation")
	private double precipitation;
	@JsonProperty("cloud_cover")
	private double cloudCover;
	@JsonProperty("weather_code")
	private int weatherCode;
	@JsonProperty("time")
	private String time;
	public double getTemperature_2m() {
		return temperature_2m;
	}
	public void setTemperature_2m(double temperature_2m) {
		this.temperature_2m = temperature_2m;
	}
	public double getRelativeHumidity_2m() {
		return relativeHumidity_2m;
	}
	public void setRelativeHumidity_2m(double relativeHumidity_2m) {
		this.relativeHumidity_2m = relativeHumidity_2m;
	}
	public double getWindSpeed_10m() {
		return windSpeed_10m;
	}
	public void setWindSpeed_10m(double windSpeed_10m) {
		this.windSpeed_10m = windSpeed_10m;
	}
	public double getWindDirection_10m() {
		return windDirection_10m;
	}
	public void setWindDirection_10m(double windDirection_10m) {
		this.windDirection_10m = windDirection_10m;
	}

	public double getPrecipitation() {
		return precipitation;
	}
	public void setPrecipitation(double precipitation) {
		this.precipitation = precipitation;
	}
	public double getCloudCover() {
		return cloudCover;
	}
	public void setCloudCover(double cloudCover) {
		this.cloudCover = cloudCover;
	}
	public int getWeatherCode() {
		return weatherCode;
	}
	public void setWeatherCode(int weatherCode) {
		this.weatherCode = weatherCode;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}


}