package Sonnenschein.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Tmp {

    @JsonProperty("value")
    private double value;

    @JsonProperty("units")
    private String units;

    @JsonProperty("tC")
    private double tC;

    @JsonProperty("tF")
    private double tF;

    @JsonProperty("is_valid")
    private boolean isValid;

    // Getters and setters

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public String getUnits() {
        return units;
    }

    public void setUnits(String units) {
        this.units = units;
    }

    public double getTC() {
        return tC;
    }

    public void setTC(double tC) {
        this.tC = tC;
    }

    public double getTF() {
        return tF;
    }

    public void setTF(double tF) {
        this.tF = tF;
    }

    public boolean isValid() {
        return isValid;
    }

    public void setValid(boolean isValid) {
        this.isValid = isValid;
    }
}