package Sonnenschein.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Hourly {
	@JsonProperty("time")
	private String[] time;
	@JsonProperty("temperature_2m")
	private double[] temperature_2m;
	@JsonProperty("precipitation_probability")
	private double[] precipitation_probability;
	@JsonProperty("cloud_cover")
	private double[] cloud_cover;
	@JsonProperty("wind_speed_10m")
	private double[] wind_speed_10m;
	@JsonProperty("wind_direction_10m")
	private double[] wind_direction_10m;
	@JsonProperty("weather_code")
	private int[] weather_code;

	
	public String[] getTime() {
		return time;
	}
	public void setTime(String[] time) {
		this.time = time;
	}
	public double[] getTemperature_2m() {
		return temperature_2m;
	}
	public void setTemperature_2m(double[] temperature_2m) {
		this.temperature_2m = temperature_2m;
	}
	public double[] getPrecipitation_probability() {
		return precipitation_probability;
	}
	public void setPrecipitation_probability(double[] precipitation_probability) {
		this.precipitation_probability = precipitation_probability;
	}
	
	public double[] getCloud_cover() {
		return cloud_cover;
	}
	
	public void setCloud_cover(double[] cloud_cover) {
		this.cloud_cover = cloud_cover;
	}
	
	public double[] getWind_speed_10m() {
		return wind_speed_10m;
	}
	
	public void setWind_speed_10m(double[] wind_speed_10m) {
		this.wind_speed_10m = wind_speed_10m;
	}
	public double[] getWind_direction_10m() {
		return wind_direction_10m;
	}
	public void setWind_direction_10m(double[] wind_direction_10m) {
		this.wind_direction_10m = wind_direction_10m;
	}
	public int[] getWeather_code() {
		return weather_code;
	}
	public void setWeather_code(int[] weather_code) {
		this.weather_code = weather_code;
	}
}
