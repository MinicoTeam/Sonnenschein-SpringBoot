package Sonnenschein.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Hum {

    @JsonProperty("value")
    private double value;

    @JsonProperty("is_valid")
    private boolean isValid;

    // Getters and setters

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public boolean isValid() {
        return isValid;
    }

    public void setValid(boolean isValid) {
        this.isValid = isValid;
    }
}