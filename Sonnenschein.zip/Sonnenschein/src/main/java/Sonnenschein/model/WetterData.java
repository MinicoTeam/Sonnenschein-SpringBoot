package Sonnenschein.model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class WetterData {

	// parameters for current weather 
	// in index.html - "weatherData"
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String timestamp;
    private double temperature;
    private double windSpeed;
    private double windDirection;
    private double precipitation;
    private double cloudCover;
    private int weatherCode;
    private String location;
    
    // parameters for Hourly forecast
    // in index.html - forecastHourly 
    private String timestamp_hourly;
    private double temperature_2m;
    private double precipitation_probability;
    private double cloudCover_hourly;
    private double windSpeed_10m;
    private double windDirection_hourly;
    private int weatherCode_hourly;

    // parameters for daily forecast
    // in index.html forecast
    private String date;
    private double temperatureMax;
    private double temperatureMin;
    private double precipitation_probability_max;
    private double windSpeedMax;
    private double windDirectionDominant;
    private int weatherCode_daily;
    
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public double getTemperature() {
		return temperature;
	}
	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}
	public double getWindSpeed() {
		return windSpeed;
	}
	public void setWindSpeed(double windSpeed) {
		this.windSpeed = windSpeed;
	}
	public double getWindDirection() {
		return windDirection;
	}
	public void setWindDirection(double windDirection) {
		this.windDirection = windDirection;
	}
	public double getPrecipitation() {
		return precipitation;
	}
	public void setPrecipitation(double precipitation) {
		this.precipitation = precipitation;
	}
	public double getCloudCover() {
		return cloudCover;
	}
	public void setCloudCover(double cloudCover) {
		this.cloudCover = cloudCover;
	}
	public int getWeatherCode() {
		return weatherCode;
	}
	public void setWeatherCode(int weatherCode) {
		this.weatherCode = weatherCode;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTimestamp_hourly() {
		return timestamp_hourly;
	}
	public void setTimestamp_hourly(String timestamp_hourly) {
		this.timestamp_hourly = timestamp_hourly;
	}
	public double getTemperature_2m() {
		return temperature_2m;
	}
	public void setTemperature_2m(double temperature_2m) {
		this.temperature_2m = temperature_2m;
	}
	public double getPrecipitation_probability() {
		return precipitation_probability;
	}
	public void setPrecipitation_probability(double precipitation_probability) {
		this.precipitation_probability = precipitation_probability;
	}
	public double getCloudCover_hourly() {
		return cloudCover_hourly;
	}
	public void setCloudCover_hourly(double cloudCover_hourly) {
		this.cloudCover_hourly = cloudCover_hourly;
	}
	public double getWindSpeed_10m() {
		return windSpeed_10m;
	}
	public void setWindSpeed_10m(double windSpeed_10m) {
		this.windSpeed_10m = windSpeed_10m;
	}
	public double getWindDirection_hourly() {
		return windDirection_hourly;
	}
	public void setWindDirection_hourly(double windDirection_hourly) {
		this.windDirection_hourly = windDirection_hourly;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public double getTemperatureMax() {
		return temperatureMax;
	}
	public void setTemperatureMax(double temperatureMax) {
		this.temperatureMax = temperatureMax;
	}
	public double getTemperatureMin() {
		return temperatureMin;
	}
	public void setTemperatureMin(double temperatureMin) {
		this.temperatureMin = temperatureMin;
	}
	public double getPrecipitation_probability_max() {
		return precipitation_probability_max;
	}
	public void setPrecipitation_probability_max(double precipitation_probability_max) {
		this.precipitation_probability_max = precipitation_probability_max;
	}
	public double getWindSpeedMax() {
		return windSpeedMax;
	}
	public void setWindSpeedMax(double windSpeedMax) {
		this.windSpeedMax = windSpeedMax;
	}
	public double getWindDirectionDominant() {
		return windDirectionDominant;
	}
	public void setWindDirectionDominant(double windDirectionDominant) {
		this.windDirectionDominant = windDirectionDominant;
	}
	public int getWeatherCode_daily() {
		return weatherCode_daily;
	}
	public void setWeatherCode_daily(int weatherCode_daily) {
		this.weatherCode_daily = weatherCode_daily;
	}
	public int getWeatherCode_hourly() {
		return weatherCode_hourly;
	}
	public void setWeatherCode_hourly(int weatherCode_hourly) {
		this.weatherCode_hourly = weatherCode_hourly;
	}

    
   
	

	
    
    
}