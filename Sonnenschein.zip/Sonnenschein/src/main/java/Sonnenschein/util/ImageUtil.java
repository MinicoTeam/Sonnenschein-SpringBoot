package Sonnenschein.util;

import org.springframework.stereotype.Component;

@Component
public class ImageUtil {

    public String getWeatherImage(String weatherCondition) {
        // Logik zur Auswahl eines Bildes basierend auf dem Wetterzustand
        return "imagePath";
    }
}
