package Sonnenschein.controller;

import Sonnenschein.model.WetterData;
import Sonnenschein.service.SensorService;
import Sonnenschein.service.WetterService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class WetterController {

    @Autowired
    private WetterService wetterService;

    @Autowired
    private SensorService sensorService;

    @GetMapping("/")
    public String index(@RequestParam(required = false) String location, Model model) {
    	WetterData wetterData = wetterService.fetchCurrentWeather(location);
        model.addAttribute("weatherData", wetterData); 
        model.addAttribute("sensorData", sensorService.getShellyData()); 
        return "currentWeather"; // name of the html file for current weather
    }
    
    @GetMapping("/currentWeather")
    
    public String getCurrentWeather(@RequestParam String location, Model model) {
    	
    // if we decide to read location from cookies:
    // public String getCurrentWeather(Model model, @CookieValue(value = "location", defaultValue = "Berlin") String location) {
    	
        WetterData wetterData = wetterService.fetchCurrentWeather(location);
        model.addAttribute("weatherData", wetterData);
        model.addAttribute("sensorData", sensorService.getShellyData()); 
        return "currentWeather"; // name of the html file for current weather
    }

    @GetMapping("/hourlyForecast")
    public String getHourlyForecast(@RequestParam String location, Model model) {
    	WetterData wetterData = wetterService.fetchCurrentWeather(location);
    	List<WetterData> forecastHourly = wetterService.fetchHourlyForecast(location);
    	
    	List<Double> averageTemperatures = wetterService.calculateAverage(forecastHourly, WetterData::getTemperature_2m);
    	List<Double> averagePrecipitationProbabilities = wetterService.calculateAverage(forecastHourly, WetterData::getPrecipitation_probability);
    	List<Double> averageCloudCovers = wetterService.calculateAverage(forecastHourly, WetterData::getCloudCover_hourly);
    	List<Double> averageWindSpeeds = wetterService.calculateAverage(forecastHourly, WetterData::getWindSpeed_10m);
    	List<Double> averageWindDirections = wetterService.calculateAverage(forecastHourly, WetterData::getWindDirection_hourly);
    	
    	model.addAttribute("weatherData", wetterData);
    	
    	model.addAttribute("forecastHourly", forecastHourly);
    	model.addAttribute("averageTemperatures", averageTemperatures);
    	model.addAttribute("averagePrecipitationProbabilities", averagePrecipitationProbabilities);
    	model.addAttribute("averageCloudCovers", averageCloudCovers);
    	model.addAttribute("averageWindSpeeds", averageWindSpeeds);
    	model.addAttribute("averageWindDirections", averageWindDirections);
    	
        model.addAttribute("location", location); 
        model.addAttribute("sensorData", sensorService.getShellyData()); 
        return "24-hour"; // name of the html file for 24-hour forecast
    }
    
    @GetMapping("/dailyForecast")
    public String getDailyForecast(@RequestParam String location, Model model) {
    	WetterData wetterData = wetterService.fetchCurrentWeather(location);
    	List<WetterData> forecastHourly = wetterService.fetchHourlyForecast(location);
    	List<WetterData> forecastDaily = wetterService.fetchDailyForecast(location);
        
    	model.addAttribute("weatherData", wetterData);
    	model.addAttribute("forecastHourly", forecastHourly);
    	
        model.addAttribute("forecastDaily", forecastDaily);
        model.addAttribute("location", location); 
        model.addAttribute("sensorData", sensorService.getShellyData()); 
        return "3day"; // name of the html file for 3-day forecast
    }
}
