package Sonnenschein.controller;

public class LocationController {

}
