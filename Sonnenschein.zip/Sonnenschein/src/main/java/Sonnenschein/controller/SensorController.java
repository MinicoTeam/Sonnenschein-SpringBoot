package Sonnenschein.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import Sonnenschein.model.SensorData;
import Sonnenschein.service.SensorService;

@Controller
public class SensorController {
	
	@Autowired
	private SensorService sensorService;
    
	@GetMapping("/sensor-data")
	public String getSensorData(Model model) {
	    System.out.println("getSensorData method called");
	    SensorData sensorData = sensorService.getShellyData();
	    model.addAttribute("sensorDataHTML", sensorData);
	    return "sensorData";
	}
}